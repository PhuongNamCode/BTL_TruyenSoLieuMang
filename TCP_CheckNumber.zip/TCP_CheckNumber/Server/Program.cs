﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "TCP Server: ";
            var listenner = new Socket(SocketType.Stream, ProtocolType.Tcp);
            listenner.Bind(new IPEndPoint(IPAddress.Any, 1308));
            listenner.Listen(10);
            Console.WriteLine($"Server started at {listenner.LocalEndPoint}");

            while (true)
            {
                var worker = listenner.Accept();

                var stream = new NetworkStream(worker);
                var reader = new StreamReader(stream);
                var writer = new StreamWriter(stream);

                var request = reader.ReadLine();
                var response = string.Empty;
                Console.WriteLine(request);

                string requestName = string.Empty;
                string requestParameter = string.Empty;


                if (request.Length >= 3)
                {
                    // cắt 3 ký tự đầu
                    requestName = request.Substring(0, 3);

                    // xoá requestName
                    requestParameter = request.Replace(requestName, "");
                }

                if (int.TryParse(requestParameter, out int number) == true)
                {
                    switch (requestName.ToUpper())
                    {
                        case "PRI":
                            bool checkPRI = true;
                            for (int i = 2; i <= Math.Sqrt(number); i++)
                            {
                                if (number % i == 0)
                                {
                                    checkPRI = false;
                                    break;
                                }
                            }

                            if (checkPRI == true)
                            {
                                response = "LA SO NGUYEN TO";
                            }
                            else
                            {
                                response = "KHONG PHAI SO NGUYEN TO";
                            }
                            break;

                        case "ODD":
                            if (number % 2 == 0)
                            {
                                response = "LA SO CHAN";
                            }
                            else
                            {
                                response = "LA SO LE";
                            }
                            break;

                        case "EVE":
                            if (number % 2 != 0)
                            {
                                response = "LA SO CHAN";
                            }
                            else
                            {
                                response = "LA SO LE";
                            }
                            break;
                        default:
                            response = "UNKNOWN COMMAND";
                            break;
                    }
                }
                else
                {
                    response = "Incorrect parameter";
                }


                writer.WriteLine(response);
                writer.Flush();
                worker.Close();

            }
        }
    }
}
